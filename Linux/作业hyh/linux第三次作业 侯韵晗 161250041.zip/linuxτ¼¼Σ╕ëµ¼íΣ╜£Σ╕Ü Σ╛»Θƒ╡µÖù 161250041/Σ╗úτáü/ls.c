#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <string.h>
#include <unistd.h>
#include <grp.h>
#include <pwd.h>
#include <time.h>

#define LS 100
#define LS_L 101
#define LS_R 102
#define LS_D 103
#define LS_I 104
#define LS_A 105

int ls(char *path);
int ls_l(char *path);
int ls_d(char *path);
int ls_R(char *path);
int ls_a(char *path);
int ls_i(char *path);

int getMode(char* param){
    if(param[1]=='l') return LS_L;
    if(param[1]=='a') return LS_A;
    if(param[1]=='d') return LS_D;
    if(param[1]=='R') return LS_R;
    if(param[1]=='i') return LS_I;
    return -1;
}

int main(int argc, char *argv[]){
    char* filepath="."; //默认路径当前路径
    int mode = LS; // 默认为无参数ls

    while(argc>1){
        argv++;
        int temp = getMode(*argv);
        if(temp!=-1){       //实际上只是实现了单mode
            mode=temp;
        }else{
            filepath=*argv;
        }
        argc--;
    }

    if(mode==LS){//无参数ls 有文件路径（其实直接ls和它调用的是一个
        ls(filepath);
    }else if(mode==LS_A){
        ls_a(filepath);
    }else if(mode==LS_D){
        ls_d(filepath);
    }else if(mode==LS_I){
        ls_i(filepath);
    }else if(mode==LS_L){
        ls_l(filepath);
    }else if(mode==LS_R){
        ls_R(filepath);
    }

}

//ls -d
int ls_d(char *path){
    struct stat st;

    if(stat(path, &st) < 0){
        printf("地址无效\n");
        return -1;
    }
    else
        printf("%s\n", path);
}

//ls -R
int rPrintDir(char* path){

    printf("%s:\n", path);
    DIR *dir;
    dir = opendir(path);
    struct dirent *dirent;

    char subPath[1024][1024];
    int num = 0;

    char buf[1024];
    struct stat st;
    while((dirent = readdir(dir)) != NULL){
        strcpy(buf, path);
        strcat(buf, "/");
        strcat(buf, dirent->d_name);
        stat(buf, &st);

        if(dirent->d_name[0] != '.'){
            printf("%s\t", dirent->d_name);
            if((st.st_mode & S_IFMT) == S_IFDIR){
                strcpy(subPath[num], buf);
                num++;
            }
        }
    }
    printf("\n");

    num--;
    for( ;num >= 0; num--){
        rPrintDir(subPath[num]);
    }
}

int ls_R(char *path){
    struct stat st;

    if(stat(path, &st) < 0){
        printf("地址无效\n");
        return -1;
    }
    else if((st.st_mode & S_IFMT) == S_IFDIR)
        rPrintDir(path);
    else
        printf("%s\n", path);
}

//ls
int printVisible(char* path){
    DIR *dir;
    dir = opendir(path);
    struct dirent *dirent;

    while((dirent = readdir(dir)) != NULL){
        if( dirent->d_name[0]=='.') {
            continue;
        }
        printf("%s\t", dirent->d_name);
    }
    printf("\n");
}

int ls(char *path){
    struct stat st;

    if(stat(path, &st) < 0){
        printf("地址无效\n");
        return -1;
    }
    else if((st.st_mode & S_IFMT) == S_IFDIR)
        printVisible(path);
    else
        printf("%s\n", path);
}


//ls -a
int printAll(char* path){
    DIR *dir;
    dir = opendir(path);
    struct dirent *dirent;

    while((dirent = readdir(dir)) != NULL){
        printf("%s\t", dirent->d_name);
    }
    printf("\n");
}

int ls_a(char *path){
    struct stat st;

    if(stat(path, &st) < 0){
        printf("地址无效\n");
        return -1;
    }
    else if((st.st_mode & S_IFMT) == S_IFDIR)
        printAll(path);
    else
        printf("%s\n", path);
}

//ls -l
int printFile(char *path, char *filename){
    struct stat st;
    stat(path, &st);

    struct passwd  *pw;
    struct group *gr;
    struct tm *tm;

    switch(st.st_mode & S_IFMT){
        case S_IFREG:  printf("-");    break;
        case S_IFDIR:  printf("d");    break;
        case S_IFLNK:  printf("l");    break;
        case S_IFBLK:  printf("b");    break;
        case S_IFCHR:  printf("c");    break;
        case S_IFIFO:  printf("p");    break;
        case S_IFSOCK: printf("s");    break;
    }

    int i;
    for(i = 8; i >= 0; i--)
    {
        if(st.st_mode & (1 << i))
        {
            switch(i%3)
            {
                case 2: printf("r"); break;
                case 1: printf("w"); break;
                case 0: printf("x"); break;
            }
        }
        else
            printf("-");
    }

    pw = getpwuid(st.st_uid);
    gr = getgrgid(st.st_gid);
    printf("%2ld %s %s %4ld", st.st_nlink, pw->pw_name, gr->gr_name, st.st_size);

    tm = localtime(&st.st_ctime);
    printf(" %04d-%02d-%02d %02d:%02d",tm->tm_year + 1900, tm->tm_mon + 1, tm->tm_mday, tm->tm_hour, tm->tm_min);

    printf(" %s\n", filename);
}
int printDir(char *dirname){
    DIR *dir;
    dir = opendir(dirname);
    struct dirent *dirent;

    char buf[1024];
    struct stat st;
    while((dirent = readdir(dir)) != NULL){
        strcpy(buf, dirname);
        strcat(buf, "/");
        strcat(buf, dirent->d_name);

        if(stat(buf, &st) < 0){
            printf("地址无效\n");
            return -1;
        }

        if(dirent->d_name[0] != '.')
            printFile(buf, dirent->d_name);
    }
}
int ls_l(char *path){
    struct stat st;

    if(stat(path, &st) < 0){
        printf("地址无效\n");
        return -1;
    }
    else if((st.st_mode & S_IFMT) == S_IFDIR)
        printDir(path);
    else
        printFile(path, path);
}

//ls -i
int printAllInode(char* path){
    DIR *dir;
    dir = opendir(path);
    struct dirent *dirent;

    char buf[1024];
    struct stat st;
    while((dirent = readdir(dir)) != NULL){
        strcpy(buf, path);
        strcat(buf, "/");
        strcat(buf, dirent->d_name);
        stat(buf, &st);

        if(dirent->d_name[0] != '.')
            printf("%9ld %s\t", st.st_ino, dirent->d_name);
    }
    printf("\n");
}

int ls_i(char *path){
    struct stat st;

    if(stat(path, &st) < 0){
        printf("地址无效\n");
        return -1;
    }
    else if((st.st_mode & S_IFMT) == S_IFDIR)
        printAllInode(path);
    else
        printf("%9ld %s\n", st.st_ino, path);
}

